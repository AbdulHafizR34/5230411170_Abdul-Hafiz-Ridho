import mysql.connector
import tkinter as tk
from tkinter import ttk, messagebox

class RetailApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Retail Management App")

        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="retail_db"
        )
        self.cursor = self.conn.cursor()

        self.setup_ui()

    def setup_ui(self):
        tab_control = ttk.Notebook(self.root)

        self.product_tab = ttk.Frame(tab_control)
        self.transaction_tab = ttk.Frame(tab_control)

        tab_control.add(self.product_tab, text="Product Management")
        tab_control.add(self.transaction_tab, text="Transaction History")

        tab_control.pack(expand=1, fill="both")

        self.setup_product_tab()
        self.setup_transaction_tab()

    def setup_product_tab(self):
        ttk.Label(self.product_tab, text="Product Name:").grid(row=0, column=0, padx=10, pady=10)
        self.product_name_entry = ttk.Entry(self.product_tab)
        self.product_name_entry.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.product_tab, text="Price:").grid(row=1, column=0, padx=10, pady=10)
        self.product_price_entry = ttk.Entry(self.product_tab)
        self.product_price_entry.grid(row=1, column=1, padx=10, pady=10)

        ttk.Label(self.product_tab, text="Stock:").grid(row=2, column=0, padx=10, pady=10)
        self.product_stock_entry = ttk.Entry(self.product_tab)
        self.product_stock_entry.grid(row=2, column=1, padx=10, pady=10)

        ttk.Button(self.product_tab, text="Add Product", command=self.add_product).grid(row=3, column=0, columnspan=2, pady=10)
        
        self.product_tree = ttk.Treeview(self.product_tab, columns=("ID", "Name", "Price", "Stock"), show="headings")
        self.product_tree.heading("ID", text="ID")
        self.product_tree.heading("Name", text="Name")
        self.product_tree.heading("Price", text="Price")
        self.product_tree.heading("Stock", text="Stock")
        self.product_tree.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

        ttk.Button(self.product_tab, text="Delete Product", command=self.delete_product).grid(row=5, column=0, pady=10)
        ttk.Button(self.product_tab, text="Update Stock", command=self.update_stock).grid(row=5, column=1, pady=10)

        self.refresh_product_tree()

    def setup_transaction_tab(self):
        self.transaction_tree = ttk.Treeview(self.transaction_tab, columns=("ID", "Product", "Quantity", "Total", "Date"), show="headings")
        self.transaction_tree.heading("ID", text="ID")
        self.transaction_tree.heading("Product", text="Product")
        self.transaction_tree.heading("Quantity", text="Quantity")
        self.transaction_tree.heading("Total", text="Total")
        self.transaction_tree.heading("Date", text="Date")
        self.transaction_tree.pack(fill="both", expand=1, padx=10, pady=10)

        self.refresh_transaction_tree()

    def add_product(self):
        name = self.product_name_entry.get()
        price = self.product_price_entry.get()
        stock = self.product_stock_entry.get()

        try:
            price = float(price)
            stock = int(stock)

            self.cursor.execute("INSERT INTO produk (nama_produk, harga_produk, stok_produk) VALUES (%s, %s, %s)", (name, price, stock))
            self.conn.commit()
            messagebox.showinfo("Success", "Product added successfully.")
            self.refresh_product_tree()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def delete_product(self):
        selected_item = self.product_tree.selection()
        if selected_item:
            product_id = self.product_tree.item(selected_item[0], "values")[0]
            try:
                self.cursor.execute("DELETE FROM produk WHERE id_produk = %s", (product_id,))
                self.conn.commit()
                messagebox.showinfo("Success", "Product deleted successfully.")
                self.refresh_product_tree()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def update_stock(self):
        selected_item = self.product_tree.selection()
        if selected_item:
            product_id = self.product_tree.item(selected_item[0], "values")[0]
            stock = self.product_stock_entry.get()
            try:
                stock = int(stock)
                self.cursor.execute("UPDATE produk SET stok_produk = stok_produk + %s WHERE id_produk = %s", (stock, product_id))
                self.conn.commit()
                messagebox.showinfo("Success", "Stock updated successfully.")
                self.refresh_product_tree()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def refresh_product_tree(self):
        for row in self.product_tree.get_children():
            self.product_tree.delete(row)

        self.cursor.execute("SELECT * FROM produk")
        for row in self.cursor.fetchall():
            self.product_tree.insert("", "end", values=row)

    def refresh_transaction_tree(self):
        for row in self.transaction_tree.get_children():
            self.transaction_tree.delete(row)

        self.cursor.execute("SELECT transaksi.id_transaksi, produk.nama_produk, transaksi.jumlah_produk, transaksi.total_harga, transaksi.tanggal_transaksi FROM transaksi JOIN produk ON transaksi.id_produk = produk.id_produk ORDER BY transaksi.tanggal_transaksi DESC")
        for row in self.cursor.fetchall():
            self.transaction_tree.insert("", "end", values=row)

if __name__ == "__main__":
    root = tk.Tk()
    app = RetailApp(root)
    root.mainloop()
